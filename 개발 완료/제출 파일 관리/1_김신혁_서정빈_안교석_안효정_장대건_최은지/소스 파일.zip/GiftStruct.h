#pragma once
#ifndef GiftStruct_h
#define GiftStruct_h
#include <stdio.h>

typedef struct {
    char gift_num[1024];
    char expiry_date[1024];
    int balance;
} gift_struct;



#endif /* GiftStruct_h */
