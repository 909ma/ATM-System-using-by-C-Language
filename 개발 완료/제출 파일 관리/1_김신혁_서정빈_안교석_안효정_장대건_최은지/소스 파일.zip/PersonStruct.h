#pragma once 
#include<stdio.h>

typedef struct {
    char BankName[20];
    int BankCode;
    int ClientCode;
    char ClientName[10];
    int CardNumber;
    int AccountNumber;
    int NowMoney;
    int AccountPW;
    int AccountDate;
} Person;
